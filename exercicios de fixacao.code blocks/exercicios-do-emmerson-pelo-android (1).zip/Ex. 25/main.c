#include <stdio.h>

int main (){
    /*declaração de variáveis*/
    float distancia_km, velocidade_kmh;
    float tempo_horas, velocidade_ms;

    /*entrada de dados*/
    printf("Digite a distancia entre os dois pontos (em km): ");
    scanf("%f", &distancia_km);

    printf("Digite a velocidade media (em km/h): ");
    scanf("%f", &velocidade_kmh);

    /*processamento*/
    tempo_horas = distancia_km / velocidade_kmh;
    velocidade_ms = velocidade_kmh / 3.6;

    /*saída*/
    printf("Tempo medio de viagem: %.2f horas\n", tempo_horas);
    printf("Velocidade convertida: %.2f m/s\n", velocidade_ms);

    return 0;
}