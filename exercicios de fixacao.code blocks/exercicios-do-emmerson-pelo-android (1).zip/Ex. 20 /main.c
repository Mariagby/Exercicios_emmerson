#include <stdio.h>

int main (){
    /*declaração de variáveis*/
    float comprimento, largura, profundidade;
    float volume, valor_total;

    /*entrada de dados*/
    printf("Digite o comprimento da piscina (em metros):");
    scanf("%f", &comprimento);

    printf("Digite a largura da piscina (em metros):");
    scanf("%f", &largura);

    printf("Digite a profundidade da piscina (em metros):");
    scanf("%f", &profundidade);

    /*processamento*/
    volume = comprimento * largura * profundidade;
    valor_total = volume * 45.00;

    /*saída*/
    printf("O volume da piscina e: %.2f m3\n", volume);
    printf("O valor total da construcao e: R$ %.2f\n", valor_total);

    return 0;
}